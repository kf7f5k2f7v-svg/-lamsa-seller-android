LAMSA Seller Android
====================

Seller URL:
https://lamsa-seller-settings-work-v1.vercel.app

Android package:
com.lamsa.seller

GitHub Actions:
.github/workflows/build-apk.yml

The workflow builds an installable APK and uploads:
seller-release.apk

This Android wrapper does not modify the Vercel seller site.
